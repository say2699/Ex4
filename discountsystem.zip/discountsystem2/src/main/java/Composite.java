
public interface Composite {
    public boolean isComposite();
    public String getName();
    public int getID();
    public float getPrice();



}
