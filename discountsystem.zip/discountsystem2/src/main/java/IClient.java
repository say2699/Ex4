public interface IClient {
    public String getName();
    public int getID();
    public ClientType getMType();

}
