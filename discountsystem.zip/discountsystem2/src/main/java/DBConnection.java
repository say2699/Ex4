
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;


public class DBConnection {
//        implements InitializingBean, DisposableBean {

    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

//    @Override
//    public void afterPropertiesSet() throws Exception {
//        this.init();
//    }

    public void setDbUrl(String dbUrl) {
        this.dbUrl = dbUrl;
    }

    public void setDbUsername(String dbUsername) {
        this.dbUsername = dbUsername;
    }

    public void setDbPassword(String dbPassword) {
        this.dbPassword = dbPassword;
    }



    public void createDbConnection() {
        init connection
        System.out.println("UserService.createDbConnection");
    }


    public void closeConnections() {
        System.out.println("UserService.closeConnections");
    }
}
