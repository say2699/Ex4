package kz.iitu.discountsystem.discountsystem2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Discountsystem2Application {

    public static void main(String[] args) {
        SpringApplication.run(Discountsystem2Application.class, args);
    }

}
