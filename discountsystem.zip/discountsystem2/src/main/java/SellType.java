public enum SellType {
    PRODUCT,SERVICE
}
