public enum ClientType {
    Premium, Gold, Silver, Regular
}
