public interface SellFactory {
    Sells createSell(String name, int id, float price);
}
