public interface Sells {
    public String getName();
    public int getID();
    public float getPrice();
    public SellType getType();
}
