public class Services {
    private String name;
    private float price;
    private int id;

}
