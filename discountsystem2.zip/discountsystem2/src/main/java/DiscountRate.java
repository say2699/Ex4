public class DiscountRate {
    static float result;

    static void discount(){

    }

}
