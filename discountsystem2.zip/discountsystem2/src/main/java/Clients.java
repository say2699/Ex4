public class Clients {
    private String name;
    private int id;
    private String type;


    public void setName(String name) {

        this.name=name;
    }

    public void setId(int id) {

        this.id=id;
    }
    public void setType(String type) {

        this.type=type;
    }


    public void show() {
        System.out.println("Tiger.eat: " + this);
    }


    public String getType(){
        return this.type;
    }


    @Override
    public String toString() {
        return "Tiger{" +
                "name='" + name + '\'' +
                ", age=" + id +
                '}';
    }
}
