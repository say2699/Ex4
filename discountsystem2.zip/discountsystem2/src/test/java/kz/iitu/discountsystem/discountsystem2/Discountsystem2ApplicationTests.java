package kz.iitu.discountsystem.discountsystem2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Discountsystem2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
